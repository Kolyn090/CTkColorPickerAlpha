from my_util import rgb_to_hsv
from my_util import hsv_to_rgb
from my_util import convert_to_value_100_rgb

if __name__ == "__main__":
    # print(rgb_to_hsv(68, 68, 68))
    # print(hsv_to_rgb(0, 0, 27))
    print(convert_to_value_100_rgb(97, 48, 48))
