from setuptools import setup

setup(name='ctk_color_picker_alpha',
      version='0.0.1',
      description='Forked from ctk_color_picker by Akash Bora. This version adds color alpha as a parameter.',
      packages=['CTkColorPickerAlpha'],
      author_email='kanzakimakai27875628@gmail.com',
      zip_safe=False)
